import "./bootstrap";
import.meta.glob(["../images/galaxy.jpg"]);

